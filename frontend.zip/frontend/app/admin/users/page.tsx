"use client";
import CrudManager,{type FieldOption} from "@/components/admin/CrudManager";
import { adminList } from "@/lib/admin-api";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import { Users } from "lucide-react";

export default function Page(){
  const load=async()=>{const r=await adminList<any>("/roles","?limit=100");return {roleId:r.rows.map(x=>({label:x.name,value:x.id})) as FieldOption[]}};
  return <div className="admin-page">
    <AdminPageHeader eyebrow="Sécurité" title="Utilisateurs" subtitle="Gérez les comptes administrateurs et employés, leurs rôles, accès et statuts." icon={<Users size={14}/>} />
    <CrudManager title="Utilisateurs" subtitle="Comptes administrateurs et employés avec rôle et statut." endpoint="/users" onLoadOptions={load}
      columns={[{key:"code",label:"Code"},{key:"first_name",label:"Prénom"},{key:"last_name",label:"Nom"},{key:"email",label:"Email"},{key:"role_name",label:"Rôle"},{key:"status",label:"Statut"}]}
      fields={[
        {name:"firstName",label:"Prénom",required:true},{name:"lastName",label:"Nom",required:true},{name:"email",label:"Email",type:"email",required:true},
        {name:"phone",label:"Téléphone"},{name:"password",label:"Mot de passe",type:"password",placeholder:"8 caractères minimum"},
        {name:"roleId",label:"Rôle",type:"select",required:true,fromRow:"role_id"},
        {name:"status",label:"Statut",type:"select",options:[{label:"Actif",value:"ACTIF"},{label:"Inactif",value:"INACTIF"},{label:"Congé",value:"CONGE"},{label:"Maladie",value:"MALADIE"}]}
      ]}/>
  </div>;
}
